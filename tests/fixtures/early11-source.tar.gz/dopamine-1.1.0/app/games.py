"""Scripted demonstrations, NOT real casino odds. Every valid round returns +100.

Randomness changes artwork only. No money is staked, lost, deposited or withdrawn.
A result is generated once, recorded with the idempotency key, and never rerolled
when a receipt is refreshed.
"""
import secrets

GAMES = ('prism', 'orbit', 'cards', 'dice', 'roulette', 'blackjack', 'baccarat', 'keno', 'plinko')
LIMITS = {'prism': 1, 'orbit': 1, 'cards': 3, 'dice': 6, 'roulette': 12,
          'blackjack': 4, 'baccarat': 3, 'keno': 20, 'plinko': 3}
ICONS = {'prism':'◇ ◇ ◇', 'orbit':'◎', 'cards':'A ♠ A', 'dice':'⚄ ⚄',
         'roulette':'◉', 'blackjack':'A ♠ K', 'baccarat':'9 : 8', 'keno':'7 · 12 · 18', 'plinko':'⋱ ● ⋰'}


def choices(game):
    maximum = LIMITS[game]
    if maximum == 1:
        return []
    labels = {
        'blackjack': ('♠', '♥', '♦', '♣'),
        'baccarat': ('player', 'banker', 'tie'),
        'plinko': ('lane_left', 'lane_center', 'lane_right'),
    }
    return [(str(n), labels[game][n-1] if game in labels else str(n))
            for n in range(1, maximum+1)]


def outcome(game, choice=1):
    if game not in GAMES or isinstance(choice, bool) or not isinstance(choice, int) or not 1 <= choice <= LIMITS[game]:
        raise ValueError('Invalid game or choice')
    result = {'schema': 1, 'choice': choice, 'scripted': True, 'bonus': 100,
              'caption': 'scripted_result', 'tiles': []}
    if game == 'prism':
        symbol = secrets.choice(('◇', '★', '◈', '◆'))
        result['tiles'] = [symbol] * 3
    elif game == 'orbit':
        result['tiles'] = ['◎', str(secrets.randbelow(12)+1), '+100']
    elif game == 'cards':
        result['tiles'] = [str(choice), 'A♠', '+100']
    elif game == 'dice':
        result['tiles'] = [chr(0x267f + choice)] * 3
    elif game == 'roulette':
        result['tiles'] = ['◉', str(choice), '+100']
    elif game == 'blackjack':
        suit = ('♠', '♥', '♦', '♣')[choice-1]
        result['tiles'] = ['A'+suit, 'K'+suit, '21']
        result['caption'] = 'blackjack_result'
    elif game == 'baccarat':
        result['tiles'] = ['9 : 8', '8 : 9', '9 : 9'][choice-1].split(' ')
        result['caption'] = ('baccarat_player', 'baccarat_banker', 'baccarat_tie')[choice-1]
    elif game == 'keno':
        others = [n for n in range(1,21) if n != choice]
        # Fisher-Yates selection: cosmetic extras, selected number always appears.
        for i in range(4):
            j = i + secrets.randbelow(len(others)-i)
            others[i], others[j] = others[j], others[i]
        result['tiles'] = [str(n) for n in sorted([choice] + others[:4])]
    elif game == 'plinko':
        result['tiles'] = [str(choice), ''.join(secrets.choice(('↙','↘')) for _ in range(4)), '+100']
    return result

"""SQLite: parameterized queries, atomic schema migration, single application node."""
from contextlib import contextmanager, closing
from pathlib import Path
import sqlite3
from .config import ROOT

def connect(path: Path):
    db = sqlite3.connect(str(path), timeout=15, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA busy_timeout=15000")
    return db

def _statements(script):
    statement = ""
    for line in script.splitlines(keepends=True):
        statement += line
        if sqlite3.complete_statement(statement):
            yield statement
            statement = ""
    if statement.strip():
        raise RuntimeError("Incomplete repository migration statement")

def initialize(path: Path):
    if path.is_symlink():
        raise RuntimeError("Database path must not be a symlink")
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(connect(path)) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=NORMAL")
        with atomic(db):
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0,1,2):
                raise RuntimeError(f"Unsupported schema version {version}; no migration performed")
            if version == 0:
                script = (ROOT / "data/schema.sql").read_text()
            elif version == 1:
                script = (ROOT / "data/migrations/002_rounds.sql").read_text()
            else:
                script = ""
            for statement in _statements(script):
                db.execute(statement)
            if db.execute("PRAGMA foreign_key_check").fetchone():
                raise RuntimeError("Foreign key validation failed")
    path.chmod(0o600)

@contextmanager
def atomic(db):
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise

def cleanup(db, now, idle_seconds=3600):
    with atomic(db):
        a=db.execute("DELETE FROM sessions WHERE expires_at<=? OR touched_at<=?",(now,now-idle_seconds)).rowcount
        b=db.execute("DELETE FROM rate_limits WHERE expires_at<=?",(now,)).rowcount
    return {"sessions_removed":a,"rate_limits_removed":b}

"""Language-selected, display-only currency labels. No exchange rates or real money.

Stored values remain non-monetary integer simulation units. A language change
never changes prices, receipts, bonuses, sorting, or account state.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class Currency:
    code: str
    symbol: str
    grouping: str = ","
    decimal: str = "."
    digits: int = 2

CURRENCIES = {
    "pt-br": Currency("BRL", "R$", ".", ","),
    "en": Currency("USD", "US$"),
    "zh": Currency("CNY", "CN¥"),
    "ja": Currency("JPY", "JP¥", digits=0),
}

def for_language(language):
    return CURRENCIES.get(language, CURRENCIES["pt-br"])

def money(value, language="pt-br"):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Simulation amounts must be integers")
    currency = for_language(language)
    amount = format(abs(value), ",").replace(",", currency.grouping)
    if currency.digits:
        amount += currency.decimal + "0" * currency.digits
    return ("−" if value < 0 else "") + currency.symbol + "\u00a0" + amount

def infinite(language="pt-br"):
    return for_language(language).symbol + "\u00a0∞"

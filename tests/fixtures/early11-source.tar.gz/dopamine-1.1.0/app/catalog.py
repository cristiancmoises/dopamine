import json
import unicodedata
from pathlib import Path
from .config import ROOT

DATA=json.loads((ROOT/'data/catalog.json').read_text())
PHOTOS=json.loads((ROOT/'data/photos.json').read_text())
_resolved=ROOT/'data/photos-resolved.json'
if _resolved.is_file():
    PHOTOS.update(json.loads(_resolved.read_text()))
PRODUCTS={p['id']:p for p in DATA['products']}
CATEGORIES={c['id']:c for c in DATA['categories']}

def folded(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',value).casefold() if not unicodedata.combining(c))

def localize(p,lang):
    q=dict(p)
    q['type']=p['type'][lang]
    q['category_label']=CATEGORIES[p['category']]['label'][lang]
    q['image']='/static/photos/'+p['photo']+'.webp'
    return q

def select(lang,category='',query='',sort='curated',favorite_ids=None):
    results=[localize(p,lang) for p in PRODUCTS.values() if not category or p['category']==category]
    if query:
        needle=folded(query)
        results=[p for p in results if needle in folded(p['name']+' '+p['type']+' '+p['category_label'])]
    if favorite_ids is not None: results=[p for p in results if p['id'] in favorite_ids]
    keys={'curated':lambda p:p['rank'],'low':lambda p:p['credits'],'high':lambda p:-p['credits'],'name':lambda p:p['name']}
    return sorted(results,key=keys.get(sort,keys['curated']))

def validate():
    assert len(PRODUCTS)==len(DATA['products']), 'Duplicate product ID'
    for p in PRODUCTS.values():
        assert p['category'] in CATEGORIES and p['photo'] in PHOTOS
        assert isinstance(p['credits'],int) and 0<p['credits']<10**12
        assert set(p['type'])=={'pt-br','en','zh','ja'}
    return len(PRODUCTS)

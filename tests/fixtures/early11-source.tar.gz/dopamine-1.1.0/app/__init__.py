"""Dopamine: fictional shopping and scripted casino simulations."""
__version__ = "1.1.0"

# Security model — Dopamine 1.1.0

This is a source-level, assisted review, not independent certification or a claim of zero vulnerabilities. See `docs/AUDIT-1.1.0.md` for executed evidence and untested areas.

## Scope

The protected assets are accounts, password hashes, sessions, recovery credentials and private history. All balances/prices are fictional. Unauthenticated clients, malicious logged-in users and forged proxy headers are considered. The Docker host, daemon, deployment operator and TLS-terminating NPM remain trusted. Host compromise, malicious browser extensions, distributed denial of service, phishing and supply-chain compromise are not solved by this application.

## Authentication and request integrity

Argon2id hashes use 64 MiB, time cost 3, parallelism 2, salt 16 bytes and hash 32 bytes. Nicknames are NFKC-normalized and casefolded for uniqueness, not verified real identities. The password rule is 12–128 characters and at least four distinct characters; the small weak-password list is not a breached-password database. Unicode lookalikes and account enumeration via duplicate nickname remain possible.

Session identifiers contain 32 random bytes and are stored as hashes. Production cookies use `__Host-dopamine`, Secure, HttpOnly, SameSite=Lax and Path=/, without a Domain attribute. Absolute expiry is 12 hours with one-hour inactivity. Login rotates sessions; password changes and recovery revoke other sessions. Signup now commits user insertion and session rotation in one SQLite transaction.

Recovery codes are random and stored as a deployment-secret-keyed HMAC. Keep SECRET_KEY stable; no email fallback is offered. The secret does not encrypt the database. Changing it is not a substitute for explicit session revocation after compromise.

POST actions require the session-bound synchronizer CSRF token. A present Origin must exactly match SITE_URL; null/foreign origins remain rejected. Cross-site and same-site Fetch Metadata submissions are refused. Missing Origin is allowed only with a valid session and token. `Referrer-Policy: same-origin` and matching HTML metadata prevent the old no-referrer/basic-form null-Origin conflict without weakening CSRF. External links also use noreferrer. Auth errors retain only safe escaped nickname/adult state, never submitted passwords or recovery secrets.

Rate limits are stored atomically in SQLite across workers. A shared NAT can trigger legitimate-user limits; distributed attacks require additional edge controls. Login and password updates recheck hashes inside the write transaction to avoid accepting a concurrent obsolete password. Already-running requests are not universally canceled when a session is revoked.

## Data and interface

Parameterized SQL, explicit transactions, foreign keys, account-scoped receipts/results and signed time-bound action keys protect mutations and replay. Catalog amounts come from the server. Maximum form body is 16 KiB, with limited field counts, query lengths, profile fields and item quantities. Templates autoescape; static assets come from a fixed preloaded set. There is no upload endpoint, public administrative API or web-triggered shell execution.

CSP uses script-src none; the UI has no JavaScript, inline scripts or third-party trackers. Same-origin assets, no-store dynamic responses, DENY framing, nosniff, restricted permissions, COOP/CORP and HSTS remain. Currency symbols are merely formatting of integer simulation units. Gameplay is scripted; cosmetic results persist and cannot be rerolled by refreshing the result page.

## NPM, Docker and deployment

The working **npm-bridge is a shared network**, not an isolated two-container segment. Other containers on it can reach the application network listener; this patch does not promise egress filtering or microsegmentation. No host application port is published. Header trust is restricted to the discovered exact NPM IPv4 /32 and/or IPv6 /128, not the entire subnet. X-Forwarded-For is ignored; NPM must overwrite X-Real-IP and forward the correct Host and HTTPS scheme. A changed proxy IP requires explicit redeployment with refreshed trust.

Runtime UID/GID is 10001, filesystem read-only except the data volume/tmpfs, all capabilities dropped, no-new-privileges, bounded PIDs/memory/CPU/log size. This does not make a compromised host safe. Rootless Docker, Podman, NFS, multi-host deployments and large concurrent loads were not validated.

The upgrade preserves the named data volume and current secret, creates private source/config/database snapshots and retains the old image. The candidate is built before downtime. POSTs stay gated during schema migration and NPM validation. Automatic snapshot restoration is allowed only before reopening writes; later restoration needs explicit acceptance and preserves newer data separately. Snapshots are **not encrypted** and include personal data plus .env; protect them, retain an encrypted off-host copy and define retention. Do not publish snapshot directories.

Dependencies retain the original pinned versions; the mutable Python base tag is not bit-reproducible. A successful build/test is not a CVE audit. Online package/scanner installation failed in the authoring environment; run your normal dependency and container scanners before broader rollout and test any resulting upgrades.

## Retention and responsible use

Expired sessions/rate-limit entries are cleaned at startup and during requests. User history remains until account deletion. Active database deletion does not automatically erase NPM logs or backups; define an actual operator retention policy. Backup scripts have their own documented retention; upgrade snapshots are intentionally not auto-deleted.

The adult declaration is not verified age checking. A separate account can bypass account-level pause settings. A fictional game can still be a trigger; it is not a treatment or a universal self-exclusion system. No automatic legal, privacy-regulatory or clinical compliance claim is made.

Report issues through the configured, monitored CONTACT_EMAIL. Do not send passwords, cookies, .env, private snapshots or recovery codes. No permission for unrelated testing of the VPS is implied.

Primary implementation references: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Origin ; https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html ; https://argon2-cffi.readthedocs.io/ ; https://jinja.palletsprojects.com/ ; https://docs.docker.com/engine/network/drivers/bridge/

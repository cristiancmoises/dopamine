# Dopamine 1.1.0

A fictional shopping and casino playground: Python WSGI, Jinja2, SQLite, local photographs, HTML forms and CSS. **No browser JavaScript.** Portuguese (Brazil) is the default; English, Simplified Chinese and Japanese are included.

**No actual purchases, deliveries, deposits, withdrawals, Pix, payment gateway or monetary value.** Casino outcomes are explicitly scripted and do not represent real casino probabilities. The site is entertainment, not treatment or evidence of increased dopamine.

## What changed

- **512 listings in 16 categories**, up from 128. All 128 original records/IDs/amounts remain unchanged. The 384 additions are 192 new fictional model families with two editions each.
- **9 games**, up from 3: Prisma, Orbit, Cards, Dice, Roulette, Blackjack, Baccarat, Keno and Plinko. Every valid simulated round returns the stake plus 100 simulation units. Cosmetic outcomes are stored; repeat submission cannot create another bonus for the same action.
- **Black #000000 page background** with cyan accents, CSS animation and reduced-motion controls.
- Registration fixes: same-origin referrer policy and HTML metadata; atomic user/session creation; clearer requirements and inline errors; language selection survives form submissions. CSRF and secure cookies remain enforced.
- Language-dependent currency formatting: **R$ / BRL**, **US$ / USD**, **CN¥ / CNY**, **JP¥ / JPY**. These are familiar symbols for fiction, not real balances or foreign-exchange calculations. Switching languages never changes a numeric amount or existing record. About explains this in all languages.
- Transactional SQLite schema v2 migration preserving original history and adding persisted game outcomes.

There are **32 photo slots shared across 512 fictional listings**, not 512 distinct photographs. Photos are category illustrations. The upgrade copies the existing downloaded photos and their SHA-256/provenance manifest from the running image; normal builds reuse them after verification. Fresh source builds download the references. See `docs/PHOTOS.md`.

## Update the existing VPS

**Use `dopamine-update-1.1.0.tar.gz`, not a fresh installation over the active directory.** The update archive includes its own README, Fish entrypoint, backup/migration checks and explicit rollback tool. It targets `/opt/dopamine`, project `dopamine`, existing volume `dopamine_dopamine-data` and working `npm-bridge`.

No NPM, firewall or DNS changes are made. It retains `http://dopamine-web:8000`, preserves SECRET_KEY and never publishes port 8000. Only the Dopamine web container is stopped/recreated, after the candidate build passes. There is a short maintenance window, not zero downtime.

## Fresh installation only

Requires Docker Engine, Docker Compose plugin 2.20 or later, Python 3 and Fish. NPM must already be running and attached to the existing user-defined `npm-bridge`. This fresh-install helper does not create or reconnect networks.

```fish
cd /opt/dopamine
fish scripts/deploy.fish --npm npm-attachment --contact admin@securityops.co
```

Confirm the contact mailbox is actually monitored. The script generates a secret only for a new configuration, obtains the exact NPM peer address, builds/tests/imports photos, and starts this project. **Do not use this fresh-install path as a substitute for the 1.0-to-1.1 migration/rollback package.**

NPM Proxy Host: domain `dopamine.securityops.co`, scheme `http`, host `dopamine-web`, port `8000`, Advanced empty, no WebSockets required. Retain a valid HTTPS certificate and Force SSL. Do not use `127.0.0.1` as the upstream inside NPM.

## Accounts

A nickname is 3–24 Unicode letters/numbers or `_`/`-`. A password is 12–128 characters with at least four distinct characters; no forced uppercase or symbols. Obvious weak examples are refused. Signup requires the adult declaration. Save the recovery code shown once; no email reset service is configured.

Reopen the signup page after upgrading. A pre-upgrade tab may still have the old referrer policy or an expired form. New errors appear in the form without returning the password. If the reverse proxy injects conflicting headers or the WAF rejects a POST, fix that specific proxy rule rather than disabling CSRF or accepting `Origin: null`.

## Verification

```fish
python3 manage.py test
python3 tests/browser_layout.py --chromium /usr/bin/chromium
```

The second command needs Playwright and Chromium in a development/test environment; neither is a runtime dependency. It renders offline HTML/CSS and is not an HTTP browser-flow test. `tests/browser_smoke.py` is the separate optional real-browser navigation test.

Executed for this release: **66 application test methods**, **16 updater tests** and **324 offline layout checks**. The application suite includes actual loopback HTTP tests and 2,048 product-page responses (512 × four languages). Test counts and limitations are in `docs/VALIDATION.md` and `docs/AUDIT-1.1.0.md`.

No Docker daemon, Fish, Gunicorn runtime or dependency scanner was available in the authoring environment. Real Chromium navigation was blocked by its environment policy. This source has not been installed on your VPS by the authoring assistant. Docker/Gunicorn tests and NPM probes run when you apply the update; image/CVE scanning and final browser acceptance remain operator checks.

## Operations and license

`docs/OPERATIONS.md` covers backups, monitoring, network trust and recovery. `SECURITY.md` records the threat model and residual risks. `docs/SCIENCE.md` retains the original references and their limitations. Existing MIT code license and third-party image/dependency notices are unchanged; scientific papers and photographs are not relicensed.

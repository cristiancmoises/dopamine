# Dopamine 1.1.0 — code audit and validation record

Date: 2026-09-06. Scope: the provided Dopamine 1.0 archive, the 1.1.0 changes and a targeted updater for the working deployment described in the conversation. **No SSH session, production database inspection or remote penetration test was performed.** This is an assisted code review with regression evidence, not an independent audit, certification, proof that every bug is fixed or assertion of zero vulnerabilities.

## Result

66 application test methods pass. 16 updater safety/failure-path test methods pass with Docker mocked. 324 offline browser layout checks pass with page JavaScript disabled. Source compiles and the operator-only Node probe passes a syntax check. Exact logs are packaged under `docs/evidence/` and the update package's `evidence/`.

The 66 application tests include the original 42 methods (catalog count expectations updated), 23 release/migration regressions, and one additional secure-proxy HTTP integration method. The complete suite was rerun successfully. The 512 product-page checks in each of four languages are **2,048 HTTP-style WSGI responses**, not 2,048 independent test methods or live NPM browser navigations.

## Reviewed components

Application dispatch and inputs; registration/login/recovery/session lifecycle; CSRF, origin and trusted-proxy handling; account-scoped profile/history/export/deletion; catalog, price validation, cart/checkout/idempotency; nine game choices, results, pauses and replay; integer display currencies; translated templates and CSS; static photo importer; SQLite schema/init/migration/backup; runtime entrypoint, Gunicorn settings and Compose; the new staged updater and explicit rollback tool.

## Findings and implemented changes

| Finding | Evidence and correction |
|---|---|
| Registration-breaking referrer/origin conflict | The original app emitted `Referrer-Policy: no-referrer` and rejected every present Origin except SITE_URL. Basic non-CORS form POSTs can have a null Origin for some referrer policies. The new header and matching HTML meta are `same-origin`; null and foreign origins are still rejected. Regression tests cover the header, metadata, successful form/session flow and deliberate null-Origin rejection. |
| Incomplete signup transaction | Original account insertion and later session rotation were separate. The new code encloses both in one transaction. An injected session-creation failure now leaves zero newly created users. |
| Registration validation loses context | Errors previously led to a generic page. The new form retains an escaped nickname and adult declaration, shows the actual validation message and password requirements, and never echoes passwords or recovery material. Duplicate nickname can be corrected and resubmitted. |
| Direct language selection lost on POST | A valid `?lang=` now sets the language cookie. Secure proxy registration and real HTTP registration retain all four languages through creation. |
| Gunicorn config regression | `forwarder_headers` remains an empty **string**, preserving the earlier deployed fix; it is not reverted to a list. Actual Gunicorn validation runs in the candidate Docker build, not in this sandbox. |
| Previously failing dedicated network could return | Both fresh-install defaults and update preflight retain the established `npm-bridge`. The updater never reconnects NPM, creates networks, publishes app ports or trusts the entire subnet. |
| Expanded game history requires a safe schema change | v1-to-v2 migration preserves original IDs, amounts, keys and timestamps while adding allowed games and persisted result JSON. DDL and row copying share one explicit transaction; foreign keys/integrity are checked. Running migration twice is supported, injected DDL failure rolls back, and unsupported future schemas are refused. |
| Cosmetic outcomes could change on replay without persistence | New game outcomes are generated once inside the action transaction and persisted. The same action key returns the same row/result; concurrent identical submissions create one round and one bonus. |
| Currency symbols could imply real balances or exchange | Currency formatting is separated from integer storage. About explains language conventions and no conversion in all languages. Existing and new records keep the same numeric amount; no FX service or real payment method was added. |
| Unsafe update rollback after reopening writes | Candidate build precedes downtime; online and cold snapshots are checked. New writes stay gated while migration/probes run. Automatic rollback refuses after reopening or when the maintenance gate is absent. Manual later rollback requires explicit acceptance and preserves newer data separately. |

The original no-referrer issue is a **confirmed source-level defect with a reproducible rejected null-Origin request**. It is consistent with the reported inability to register, but the exact failing browser request from the live VPS was not supplied or captured. A separate browser extension, stale form, cookie restriction, proxy header, WAF rejection or rate limit can still require deployment-specific diagnosis. The patch does not claim to have observed or fixed an unknown live WAF rule.

## Security properties tested

The test suite exercises account-bound receipts/results; XSS escaping; bad/missing/foreign-origin CSRF; disallowed methods/hosts/body sizes; secure cookies and trusted proxy metadata; session rotation/expiry; recovery-code rotation and password change revocation; login/password-reset concurrency; atomic rate limiting; time-bound action keys; checkout replay and concurrent checkout; game replay and concurrent duplicate rounds; pause enforcement, ownership and invalid choices; export without credentials; account deletion cascades; controlled photo URL/type/size/provenance checks; consistent backup; and schema migration rollback.

The new nine-game integration test runs every game in each of four languages (36 stored rounds), and the outcome test exercises every allowed choice. Keno always includes the chosen number and has five unique cosmetic number tiles. All valid games credit exactly 100 simulation units and retain the stake. These are deliberately scripted demos, not gambling fairness/RNG probability certification.

All original 128 catalog dictionaries are checked against an exact fixture; IDs, category, amount and other existing fields remain equal. The total is 512 uniquely named listings. The additional 384 are 192 new fictional model families with two editions, not 384 newly photographed real offers. There are 32 shared local photo slots.

## Browser/layout evidence

Chromium rendered the actual server-produced HTML with the project's CSS at widths **1440, 390 and 360** in four languages, across 27 public/private/game/result views: **324 checks**. Horizontal overflow, absence of script tags and computed black body background were asserted. Native language-details and reduce-motion controls were exercised. Desktop/mobile shop/casino screenshots were visually inspected.

This was **offline `set_content` rendering**, not browser navigation through HTTP/TLS. Chromium's managed environment blocked actual navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`, including loopback. Therefore browser-driven signup/cookie acceptance, live CSP behavior under network delivery, external navigation and full real-browser end-to-end flows were not validated here. The optional browser_smoke.py remains for a permissive test environment.

No real photo binaries were present in the authoring source. Layout checks used explicitly marked development placeholders. They do not validate the crops, content, permissions or decoding of the 32 deployed photos. The update imports those already downloaded binaries from the running container and verifies them during build; a fresh build downloads the original references.

## Upgrade design and evidence boundaries

Updater unit tests check plain-env parsing, duplicate/interpolation rejection, private atomic writes, symlink/path traversal rejection, source hashes/unexpected files, SQLite integrity/schema, project-scoped Compose commands, unprivileged offline helpers, refusal of rollback after live opening or without the gate, restoration of previous managed source/env, retention of unrelated files, explicit manual-restore acceptance, strict TLS context selection and wrong-service rejection. These tests **mock Docker** and do not prove a working Docker deployment or disaster recovery on the VPS.

Actual operator-side acceptance includes candidate `manage.py test`, Gunicorn `--check-config`, photo verification, online/cold database-copy migration, service health, NPM internal probes and a strict local HTTPS probe. During verification, a valid signup POST must return the app's explicit maintenance marker without creating an account; invalid CSRF must return 403. A reachable HTTPS proxy with the wrong service/header or a rejected valid POST fails validation. Certificate/listener connection failures are reported as unverified rather than bypassing TLS checks. Public DNS, IPv6 and external routing remain separate checks.

The updater has conservative capacity limits: at least 1 GiB free in the project filesystem, a 128 MiB maximum validated database snapshot and bounded offline helper memory/tmpfs. Docker storage needs its own capacity monitoring. Normal backups and upgrade snapshots are unencrypted, contain personal data, and must be private. Upgrade snapshot retention is manual. SIGKILL, power failure, corrupted storage or a broken Docker daemon can interrupt the procedure beyond automatic recovery; keep an off-host backup and rehearse recovery.

## Dependency and runtime limitations

Docker, Fish, Gunicorn, Bandit and pip-audit were not installed in the authoring runtime. An isolated installation attempt failed because the package host could not be resolved. Consequently **no completed dependency/CVE scan, container image scan, Docker build, Fish execution or Gunicorn runtime test is claimed here**. Version-pinned dependencies are retained from the user's already built package; this does not mean they are latest or free from vulnerabilities. The candidate build requests a current Python base tag; it is mutable rather than digest-reproducible.

The test run used the available global Python/Jinja2/Argon2 libraries; `docs/evidence/environment.json` records them. Those can differ from the runtime requirements pins. The operator build reruns the suite with the pinned libraries. Updating pins based on scanner findings still needs regression testing; do not blindly substitute versions or suppress vulnerabilities.

No performance/load test, formal verification, independent cryptographic audit, legal compliance assessment or clinical outcome study was performed. The application uses SQLite on one host with bounded workers; infinite fictional balance does not mean unlimited capacity. Shared npm-bridge is not an isolated application network and permits other attached containers to reach the app listener. Host/NPM compromise and distributed abuse remain outside the application guarantees. Nickname enumeration, Unicode lookalikes, self-declared age, per-account self-exclusion and a small weak-password blocklist remain documented limitations.

## Primary technical references consulted

- MDN, Origin request header, including null Origin and basic form/referrer-policy interactions: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Origin
- OWASP, Cross-Site Request Forgery Prevention Cheat Sheet, synchronizer tokens and origin/Fetch Metadata defenses: https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html

The scientific content inherited from the original source remains qualified; the new release makes no claim that simulated shopping or scripted wins measurably raise dopamine or treat a condition.

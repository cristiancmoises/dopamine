# Validation — version 1.1.0

Executed: 66 application test methods, 16 updater test methods (Docker mocked), 324 offline Chromium layout checks. The application suite includes real loopback HTTP integration and 2,048 product-page responses (512 products × four languages). Full details, fixes, scope and limitations: `AUDIT-1.1.0.md`.

Run `python3 manage.py test` from the source tree. Run `python3 test_updater.py` from the update package. Optional offline browser checks: `python3 tests/browser_layout.py --chromium /usr/bin/chromium` (Playwright required in the test environment). Actual navigation test: `tests/browser_smoke.py`, not completed here because Chromium navigation was blocked by its environment policy.

Docker, Fish, Gunicorn runtime and vulnerability scans were unavailable in the authoring environment. No live VPS audit or deployment was performed. The candidate Docker build and NPM validation run when the operator applies the patch. This is not a zero-bug/security-certification claim.

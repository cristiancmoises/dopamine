# Operations — Dopamine 1.1.0

## Known installation

`/opt/dopamine`, Compose project `dopamine`, service `web`, volume `dopamine_dopamine-data`. Existing NPM `npm-attachment` uses `npm-bridge`; upstream stays `http://dopamine-web:8000`. Do not reintroduce the previously failing dedicated network.

## Fish commands

```fish
cd /opt/dopamine
docker compose -p dopamine -f compose.yaml --env-file .env ps
docker compose -p dopamine -f compose.yaml --env-file .env logs --tail=100 web
docker compose -p dopamine -f compose.yaml --env-file .env exec -T web python manage.py cleanup
fish scripts/backup.fish
```

The cleanup command removes expired sessions and rate-limit entries, not accounts, purchases or rounds. Background cleanup runs on startup and periodically during requests; no system timer is installed.

## Backups

Schedule `python3 /opt/dopamine/scripts/backup.py` using the scheduler you administer. A backup is created with SQLite's online backup API and checked for integrity. The supplied backup script removes only its own backups older than 14 days after a new successful backup. That policy only runs when the script runs.

Backups and upgrade snapshots are not encrypted. Keep protected off-host copies and the matching .env; recovery codes depend on SECRET_KEY. Normal database backups do not contain photos; keep the image/source/photo manifest too. Upgrade snapshots include those source/image references. Account deletion does not delete historical backups or NPM logs. Define retention and track any requests needing reapplication after restoring older data.

## Applying this release

Use the separate `dopamine-update-1.1.0` package and its `apply-update.fish`. It builds before stopping the app, verifies an online copy migration, stops only web, saves a cold snapshot, migrates, probes and reopens writes. Source snapshots, previous.env, old image tags and database snapshots are recorded under `/opt/dopamine-upgrades/<timestamp>/state.json`.

Preflight requires the known project/network/volume, a valid plain KEY=value .env, and at least 1 GiB free on the deployment filesystem. Database-copy validation refuses snapshots over 128 MiB rather than overrunning its bounded temporary filesystem. These are conservative limits, not a storage or capacity forecast. Docker's own storage may need additional free space for image layers. Nothing is automatically pruned.

A normal failed update before writes reopen attempts to restore the old source/config/cold database snapshot, retaining failed candidate data separately. After reopening, automatic snapshot rollback is disabled because it could discard new user activity. Manual `rollback.fish --snapshot EXACT_PATH --restore-snapshot` requires explicit acceptance; it backs up current data first and restores the old state without merging later activity. Review the package README before using it.

A host power failure or SIGKILL cannot execute cleanup or automatic rollback. Keep snapshots/volume intact, inspect state.json and container status. A maintenance marker may remain; do not blindly delete it while a restore or migration is running. Complete validation or use the explicit restore procedure. Never copy a SQLite file over a running database, delete volumes, run down -v, or use broad volume-pruning commands.

## NPM and registration diagnostics

After upgrading, reopen `/signup` to obtain fresh cookies/token/referrer policy. Nickname: 3–24 letters/numbers/_/-. Password: 12–128 characters with at least four distinct characters. Check the adult declaration and save the one-time recovery code.

A 403 still needs the actual response: inspect Origin, form token/cookie, the exact trusted NPM peer, forwarded scheme and any NPM/WAF rule. Do not disable CSRF, allow all proxies or blanket-allow null Origin. The updater tests the application from NPM and, when strict local HTTPS is available, also submits a valid form through NPM while the maintenance gate prevents account creation. A HTTP-level proxy rejection aborts validation rather than being called a working signup.

The strict local TLS probe connects to 127.0.0.1:443 with the domain's SNI and certificate verification. It does not test public DNS, IPv6, ISP paths or external firewalls. No insecure `-k` result is accepted as certificate proof. Failure to establish strict local TLS is reported as unverified; a reachable HTTPS proxy with a wrong service or rejected valid POST fails the update.

If the NPM IP changes, inspect its existing npm-bridge attachment and run `fish scripts/deploy.fish --npm npm-attachment --skip-build` to refresh exact peer trust and recreate only Dopamine. This command does not reconnect or edit NPM. Never substitute a public VPS IP/localhost upstream or expose port 8000 to bypass a network issue.

## Capacity and acceptance

One host, two Gunicorn workers, two threads per worker, SQLite WAL, memory limit 768 MiB. There is no claim of unlimited throughput or latency. Argon2 consumes 64 MiB per active password check. Monitor memory, disk, response times, 4xx/5xx rates and shared-IP throttling before adjusting limits. Upgrade snapshots consume extra disk and have no automatic cleanup.

After application: check health/version, real browser signup/login, one purchase, each new game, language/currency switch, mobile layout, all category photos, password recovery and the public contact. Do not share secrets or full private logs as part of support diagnostics. Docker/TLS/public browser acceptance must be performed on the actual deployment.

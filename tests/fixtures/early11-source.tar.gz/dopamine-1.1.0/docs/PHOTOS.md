# Fotografias, fontes e build

Esta versão contém 32 referências do Unsplash em `data/photos.json`, duas por categoria, compartilhadas entre **512 anúncios/edições fictícios**. Não são 512 fotos exclusivas nem anúncios reais. As imagens ilustram a categoria; não há correspondência garantida com cada modelo imaginário. O patch preserva as fotos já baixadas no container em execução, copia o manifesto resolvido e verifica os hashes no novo build. Uma instalação nova baixa as referências durante o build.

**Os arquivos binários das fotografias não foram baixados no ambiente de criação.** Tentativas de saída de rede falharam. A entrega não inclui desenhos ou placeholders apresentados como se fossem fotografias. O modo de desenvolvimento sinaliza ausências; o entrypoint de produção exige os arquivos e seu manifesto de integridade.

## Como são obtidas

O Dockerfile executa `python manage.py photos` durante o build, em uma etapa com rede, e `python manage.py verify-photos` em seguida. Cada URL é limitada a HTTPS, host `images.unsplash.com`, porta padrão e caminho `/photo-...`. Redirecionamentos passam pela mesma verificação. Exige resposta 200, tipo WebP, tamanho de até 2 MiB, assinatura do contêiner WebP e comprimento RIFF coerente. Isso verifica transporte/formato básico; não é uma análise visual do assunto nem uma varredura universal do decodificador.

Há até três tentativas por referência e até quatro downloads paralelos. Se uma referência fica indisponível, a outra fotografia já importada da **mesma categoria** pode preencher a posição. O manifesto registra a URL efetiva, source_key, hash, data e motivo. Não se usa uma foto de outra categoria nem uma ilustração inventada para esconder a falha. Com `--strict-unique`, essa substituição é desativada.

O build falha se qualquer categoria continuar sem fotografia. Nunca resolva isso desativando `REQUIRE_LOCAL_PHOTOS` em produção; o entrypoint rejeita essa configuração. Corrija a referência ou o acesso de rede e reconstrua.

## Arquivos gerados

`app/static/photos/*.webp`: os arquivos que o visitante recebe **do próprio domínio**.

`data/photos-resolved.json`: procedência efetiva e SHA-256 de cada posição. Os créditos da aba Sobre usam essas origens. Quando houve substituição, os nomes de referência podem repetir; a foto continua sendo identificada como ilustrativa.

Nenhum navegador precisa acessar Unsplash para navegar pelo catálogo. Somente clicar voluntariamente em um crédito/artigo abre o serviço externo. O runtime não faz downloads de fotografias; a rede compartilhada npm-bridge não equivale a isolamento de saída.

## Revisão do operador antes de publicar

Confira todas as categorias e pelo menos cada uma das 32 posições. Verifique imagem realmente fotográfica, assunto, recorte em celular, textos alternativos, marcas/pessoas/propriedades visíveis, licença e uso pretendido. Disponibilidade de URL não prova que o conteúdo nunca mudou, que o titular consentiu com qualquer uso, ou que marcas endossam o projeto. A URL inicial não fornece metadados de autoria suficientes; por isso o projeto não inventa nomes de fotógrafos.

A licença de referência está em https://unsplash.com/license . A licença do código **não** reclassifica fotografias como MIT. O projeto não oferece arquivo de fotos à venda nem promete propriedade sobre os bens retratados. Caso substitua uma imagem, registre sua fonte e direitos e atualize os textos conforme necessário.

## Diagnóstico

`PHOTO RETRY EXHAUSTED` seguido de `PHOTO CATEGORY FALLBACK` indica uma substituição registrada. `Photo import incomplete` significa que a loja ainda não está pronta para publicar. Observe o identificador, verifique DNS/HTTPS e ajuste o manifesto com uma fonte permitida.

No container construído:

```fish
docker compose -p dopamine -f compose.yaml exec -T web python manage.py verify-photos
docker compose -p dopamine -f compose.yaml exec -T web python -m json.tool /app/data/photos-resolved.json
```

A verificação de hash confirma a consistência com **o download do build**, não uma comparação com um hash previamente autenticado pelo fotógrafo. O serviço externo é parte da cadeia de confiança do build. Guarde a imagem Docker produzida para conservar aquela versão das fotos.

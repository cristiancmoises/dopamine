"""1.1.0 regressions: registration, secure proxy, currencies, nine games and migrations."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import json
import sqlite3
import unittest
from app import catalog, db, security
from app.config import Config, LANGUAGES, ROOT
from app.currency import money, infinite, for_language
from app.games import GAMES, LIMITS, outcome
from app.web import App, safe_next
from tests.helpers import Client

PASSWORD='Cyan release tests 2026!'

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'test.sqlite3'; db.initialize(self.path)
        self.config=Config(secret='release-test-secret-'*4,database=self.path,site_url='http://localhost',
                           allowed_hosts=('localhost',),secure=False,require_local_photos=False,testing=True)
        self.app=App(self.config); self.client=Client(self.app)
    def scalar(self,sql,args=()):
        with closing(db.connect(self.path)) as connection:
            return connection.execute(sql,args).fetchone()[0]
    def signup(self,client=None,name='release_test',lang='pt-br'):
        client=client or self.client
        response=client.submit(client.get('/signup?lang='+lang),'/signup',nickname=name,password=PASSWORD,adult='yes')
        self.assertEqual(response.status,200,response.text)
        self.assertIn('id="recovery-code"',response.text)
        return response

    def test_referrer_policy_preserves_form_origin(self):
        page=self.client.get('/signup')
        self.assertEqual(page.header('Referrer-Policy'),'same-origin')
        self.assertIn('<meta name="referrer" content="same-origin">',page.text)
        self.assertEqual(page.header('Cache-Control'),'no-store, private')
        self.assertIn("script-src 'none'",page.header('Content-Security-Policy'))

    def test_null_origin_is_not_whitelisted(self):
        page=self.client.get('/signup')
        response=self.client.post('/signup',dict(page.form('/signup'),nickname='null_test',password=PASSWORD,adult='yes'),headers={'HTTP_ORIGIN':'null'})
        self.assertEqual(response.status,403)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),0)

    def test_registration_rejects_missing_cookies(self):
        page=self.client.get('/signup'); self.client.cookies.clear()
        response=self.client.submit(page,'/signup',nickname='no_cookie',password=PASSWORD,adult='yes')
        self.assertEqual(response.status,403)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),0)

    def test_invalid_password_keeps_nickname_not_secret(self):
        page=self.client.get('/signup')
        response=self.client.submit(page,'/signup',nickname='keep_my_nickname',password='DontEcho9',adult='yes')
        self.assertEqual(response.status,400)
        self.assertIn('value="keep_my_nickname"',response.text)
        self.assertNotIn('DontEcho9',response.text)
        self.assertIn('role="alert"',response.text)
        self.assertIn('12',response.text)

    def test_duplicate_account_can_retry_from_form(self):
        self.signup()
        client=Client(self.app,ip='203.0.113.55')
        page=client.get('/signup')
        response=client.submit(page,'/signup',nickname='release_test',password=PASSWORD,adult='yes')
        self.assertEqual(response.status,409)
        self.assertIn('value="release_test"',response.text)
        response=client.submit(response,'/signup',nickname='another_name',password=PASSWORD,adult='yes')
        self.assertEqual(response.status,200)

    def test_atomic_signup_does_not_leave_orphan_account(self):
        page=self.client.get('/signup')
        with patch('app.security.new_session',side_effect=sqlite3.OperationalError('injected session failure')):
            with self.assertLogs('dopamine',level='ERROR'):
                response=self.client.submit(page,'/signup',nickname='must_not_exist',password=PASSWORD,adult='yes')
        self.assertEqual(response.status,503)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),0)

    def test_secure_proxy_registration_in_four_languages(self):
        cfg=replace(self.config,secure=True,site_url='https://dopamine.securityops.co',
                    allowed_hosts=('dopamine.securityops.co',),proxy_cidrs=('172.18.0.2/32',))
        app=App(cfg)
        for n,lang in enumerate(LANGUAGES):
            client=Client(app,ip='172.18.0.2')
            headers={'HTTP_HOST':'dopamine.securityops.co','HTTP_X_FORWARDED_PROTO':'https',
                     'HTTP_X_REAL_IP':f'203.0.113.{60+n}','HTTP_ORIGIN':cfg.site_url,'HTTP_SEC_FETCH_SITE':'same-origin'}
            page=client.get('/signup?lang='+lang,headers=headers)
            self.assertEqual(page.status,200)
            form=page.form('/signup'); form.update(nickname='proxy_'+lang,password=PASSWORD,adult='yes')
            response=client.post('/signup',form,headers=headers)
            self.assertEqual(response.status,200,response.text)
            self.assertIn('id="recovery-code"',response.text)
            cookies='\n'.join(v for k,v in response.headers if k.lower()=='set-cookie')
            for value in ('__Host-dopamine=','Secure','HttpOnly','SameSite=Lax','Path=/'):
                self.assertIn(value,cookies)
            self.assertEqual(self.scalar('SELECT language FROM users WHERE nickname=?',('proxy_'+lang,)),lang)

    def test_cross_site_and_same_site_posts_rejected(self):
        for site in ('cross-site','same-site'):
            page=self.client.get('/signup')
            response=self.client.post('/signup',dict(page.form('/signup'),nickname='blocked_'+site,password=PASSWORD,adult='yes'),headers={'HTTP_SEC_FETCH_SITE':site,'HTTP_ORIGIN':None})
            self.assertEqual(response.status,403)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),0)

    def test_currency_formatting_and_no_float_money(self):
        expected={'pt-br':'R$\u00a01.234,00','en':'US$\u00a01,234.00','zh':'CN¥\u00a01,234.00','ja':'JP¥\u00a01,234'}
        for language,display in expected.items():
            self.assertEqual(money(1234,language),display)
            self.assertIn('∞',infinite(language))
        for value in (1.25,'100',True):
            with self.assertRaises(ValueError):money(value)

    def test_switching_language_does_not_convert_receipts(self):
        self.signup()
        page=self.client.get('/product/cars-1-1')
        receipt=self.client.submit(page,'/buy/cars-1-1',quantity='1')
        saved=self.scalar('SELECT unit_credits FROM purchase_items')
        for language in LANGUAGES:
            result=self.client.get(receipt.location+'?lang='+language)
            self.assertEqual(result.status,200)
            self.assertIn(money(saved,language),result.text)
            self.assertEqual(self.scalar('SELECT unit_credits FROM purchase_items'),saved)

    def test_about_explains_each_currency_without_exchange_rates(self):
        for lang in LANGUAGES:
            page=self.client.get('/about?lang='+lang)
            self.assertEqual(page.status,200)
            self.assertIn('id="currency"',page.text)
            for code in ('BRL','USD','CNY','JPY'):self.assertIn(code,page.text)
            self.assertNotIn('DC ',page.text)

    def test_every_game_choice_has_a_scripted_fixed_bonus(self):
        self.assertEqual(len(GAMES),9)
        for game in GAMES:
            for choice in range(1,LIMITS[game]+1):
                result=outcome(game,choice)
                self.assertEqual(result['bonus'],100)
                self.assertTrue(result['scripted'])
                self.assertEqual(result['choice'],choice)
                self.assertTrue(result['tiles'])
                if game=='keno':
                    self.assertEqual(len(result['tiles']),5)
                    self.assertEqual(len(set(result['tiles'])),5)
                    self.assertIn(str(choice),result['tiles'])
            for bad in (0,-1,LIMITS[game]+1,True):
                with self.assertRaises(ValueError):outcome(game,bad)

    def test_nine_games_rounds_and_locale_integration(self):
        for n,lang in enumerate(LANGUAGES):
            client=Client(self.app,ip=f'203.0.113.{80+n}')
            self.signup(client,'games_'+lang,lang)
            for game in GAMES:
                page=client.get('/casino/'+game)
                self.assertEqual(page.status,200,page.text)
                values={'stake':'500',('card' if game=='cards' else 'choice'):str(LIMITS[game])}
                response=client.submit(page,'/casino/'+game,**values)
                self.assertEqual(response.status,303,response.text)
                result=client.get(response.location)
                self.assertEqual(result.status,200,result.text)
                self.assertIn(money(100,lang),result.text)
                self.assertIn('outcome-tiles',result.text)
                self.assertEqual(safe_next('/casino/'+game),'/casino/'+game)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM rounds'),36)

    def test_game_result_and_bonus_are_idempotent(self):
        self.signup();page=self.client.get('/casino/keno')
        response=self.client.submit(page,'/casino/keno',choice='7',stake='100')
        stored=self.scalar('SELECT result_json FROM rounds')
        replay=self.client.submit(page,'/casino/keno',choice='19',stake='500')
        self.assertEqual(response.location,replay.location)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM rounds'),1)
        self.assertEqual(self.scalar('SELECT result_json FROM rounds'),stored)
        self.assertEqual(self.client.get(response.location).body,self.client.get(response.location).body)

    def test_game_replay_is_safe_under_concurrency(self):
        self.signup();page=self.client.get('/casino/dice')
        form=dict(page.form('/casino/dice'),choice='6',stake='1000')
        def submit(_):return Client(self.app,cookies=self.client.cookies).post('/casino/dice',form)
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(submit,range(4)))
        self.assertTrue(all(r.status==303 for r in results))
        self.assertEqual(len({r.location for r in results}),1)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM rounds'),1)

    def test_new_games_enforce_pause_and_ownership(self):
        self.signup();page=self.client.get('/casino/plinko')
        first=self.client.submit(page,'/casino/plinko',choice='2',stake='100')
        other=Client(self.app,ip='203.0.113.99');self.signup(other,'other_game_user')
        self.assertEqual(other.get(first.location).status,404)
        self.client.submit(self.client.get('/casino'),'/casino/pause',days='1')
        for game in GAMES:self.assertEqual(self.client.get('/casino/'+game).status,403)
        self.assertEqual(self.client.submit(page,'/casino/plinko',choice='1',stake='100').status,403)

    def test_invalid_new_game_input_is_not_persisted(self):
        self.signup()
        for game in GAMES:
            page=self.client.get('/casino/'+game)
            bad={'stake':'100',('card' if game=='cards' else 'choice'):str(LIMITS[game]+1)}
            self.assertEqual(self.client.submit(page,'/casino/'+game,**bad).status,400)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM rounds'),0)

    def test_maintenance_does_not_create_accounts_or_orders(self):
        (self.path.parent/'.dopamine-upgrading').write_text('operator maintenance')
        page=self.client.get('/signup')
        response=self.client.submit(page,'/signup',nickname='not_created',password=PASSWORD,adult='yes')
        self.assertEqual(response.status,503)
        self.assertEqual(self.scalar('SELECT COUNT(*) FROM users'),0)
        self.assertEqual(self.client.get('/healthz').status,200)

    def test_black_background_and_no_browser_javascript(self):
        css=(ROOT/'app/static/style.css').read_text()
        self.assertIn('--bg:#000000;',css)
        self.assertIn('html,body,.site{background:#000',css)
        for page in ('/signup','/casino','/shop','/about'):
            result=self.client.get(page)
            self.assertIn('content="#000000"',result.text)
            self.assertNotIn('<script',result.text.lower())

    def test_catalog_preserves_legacy_ids_and_prices(self):
        legacy=json.loads((ROOT/'tests/fixtures/catalog_v1.json').read_text())
        for product in legacy['products']:
            self.assertEqual(catalog.PRODUCTS[product['id']],product)
        self.assertEqual(catalog.validate(),512)
        self.assertEqual(len({p['name'] for p in catalog.PRODUCTS.values()}),512)

class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'v1.sqlite3'
        with closing(sqlite3.connect(self.path)) as conn:
            conn.executescript((ROOT/'tests/fixtures/schema_v1.sql').read_text())
            conn.execute("INSERT INTO users(id,nickname,nickname_key,password_hash,recovery_hash,adult_confirmed,created_at) VALUES(1,'legacy','legacy','hash','recovery',1,1)")
            conn.execute("INSERT INTO rounds(id,user_id,game,request_key,stake,bonus,created_at) VALUES('old-round',1,'cards','old-key',500,100,1)")
            conn.execute("INSERT INTO purchases(id,user_id,request_key,created_at) VALUES('old-order',1,'order-key',1)")
            conn.execute("INSERT INTO purchase_items(purchase_id,product_id,quantity,unit_credits) VALUES('old-order','cars-1-1',2,2400000)")
            conn.commit()
    def test_migrate_v1_preserves_records_and_accepts_new_games(self):
        db.initialize(self.path);db.initialize(self.path)
        with closing(db.connect(self.path)) as conn:
            self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0],2)
            self.assertEqual(conn.execute('SELECT nickname FROM users').fetchone()[0],'legacy')
            self.assertEqual(conn.execute('SELECT unit_credits FROM purchase_items').fetchone()[0],2400000)
            self.assertEqual(conn.execute('SELECT result_json FROM rounds').fetchone()[0],'{}')
            for game in GAMES:
                conn.execute('INSERT INTO rounds(id,user_id,game,request_key,stake,bonus,created_at) VALUES(?,1,?,?,100,100,1)',(game,game,'key-'+game))
            self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0],'ok')
            self.assertIsNone(conn.execute('PRAGMA foreign_key_check').fetchone())
    def test_failed_migration_rolls_back_ddl_and_data(self):
        def broken(script):
            yield 'DROP INDEX rounds_user_time;'
            yield 'ALTER TABLE rounds RENAME TO rounds_v1;'
            yield 'THIS IS INVALID SQL;'
        with patch('app.db._statements',broken):
            with self.assertRaises(sqlite3.OperationalError):db.initialize(self.path)
        with closing(db.connect(self.path)) as conn:
            self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0],1)
            self.assertEqual(conn.execute('SELECT id FROM rounds').fetchone()[0],'old-round')
            self.assertIsNotNone(conn.execute("SELECT name FROM sqlite_master WHERE name='rounds_user_time'").fetchone())
    def test_future_schema_is_not_downgraded(self):
        with closing(db.connect(self.path)) as conn:conn.execute('PRAGMA user_version=99')
        with self.assertRaises(RuntimeError):db.initialize(self.path)
        with closing(db.connect(self.path)) as conn:self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0],99)

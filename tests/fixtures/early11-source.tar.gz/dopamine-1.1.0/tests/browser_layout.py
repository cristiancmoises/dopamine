#!/usr/bin/env python3
"""Offline layout-only QA, for sandboxes that block browser loopback networking.

Renders the actual server-produced HTML and project CSS in a JavaScript-disabled
browser without an HTTP transport. This does NOT validate TLS, Gunicorn or the
Docker network. Full HTTP flows have a separate optional browser_smoke.py test.
"""
import argparse
import json
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app import db
from app.config import Config
from app.web import App
from tests.helpers import Client
from app.games import GAMES

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--chromium',default='/usr/bin/chromium')
    parser.add_argument('--screenshots',type=Path)
    args=parser.parse_args()
    if args.screenshots:args.screenshots.mkdir(parents=True,exist_ok=True)
    from playwright.sync_api import sync_playwright
    report={'transport':'offline server-rendered HTML + identical project CSS',
            'javascript_enabled':False,'real_http_transport_tested':False,'layout_checks':[],
            'photo_binaries_present':len(list((ROOT/'app/static/photos').glob('*.webp')))}
    css=(ROOT/'app/static/style.css').read_text()
    with TemporaryDirectory() as temp:
        path=Path(temp)/'db.sqlite3';db.initialize(path)
        app=App(Config(secret='offline-layout-test-key'*4,database=path,site_url='http://localhost',
            allowed_hosts=('localhost',),secure=False,require_local_photos=False,testing=True))
        client=Client(app)
        signed=Client(app,ip='203.0.113.99')
        auth=signed.get('/signup')
        signed.submit(auth,'/signup',nickname='layout_user',password='Cyan-Layout-2026!Test',adult='yes')
        round_paths=[]
        for game in GAMES:
            form=signed.get('/casino/'+game)
            result=signed.submit(form,'/casino/'+game,stake='100',**({'card':'1'} if game=='cards' else {'choice':'1'}))
            assert result.status==303,result.text
            round_paths.append(result.location)
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path=args.chromium,headless=True,args=['--no-sandbox'])
            report['browser_version']=browser.version
            context=browser.new_context(java_script_enabled=False,reduced_motion='reduce')
            page=context.new_page()
            for width,height in ((1440,1000),(390,844),(360,800)):
                page.set_viewport_size({'width':width,'height':height})
                for lang in ('pt-br','en','zh','ja'):
                    for endpoint in ('/shop','/casino','/science','/about','/signup','/product/homes-1-1','/profile','/collection','/cart')+tuple('/casino/'+g for g in GAMES)+tuple(round_paths):
                        session=client if endpoint=='/signup' else signed
                        result=session.get(endpoint+'?lang='+lang)
                        assert result.status==200
                        html=re.sub(r'<link\b[^>]*>','',result.text)
                        html=html.replace('</head>','<style>'+css+'</style></head>')
                        page.set_content(html,wait_until='load')
                        dimensions=page.evaluate('({viewport:innerWidth,width:document.documentElement.scrollWidth})')
                        check=dict(path=endpoint,language=lang,viewport=width,content_width=dimensions['width'])
                        report['layout_checks'].append(check)
                        assert dimensions['width']<=width+1,check
                        assert page.locator('script').count()==0
                        assert page.evaluate('getComputedStyle(document.body).backgroundColor')=='rgb(0, 0, 0)' 
                        if args.screenshots and lang=='pt-br' and width in (1440,390) and endpoint in ('/shop','/casino'):
                            page.screenshot(path=str(args.screenshots/f'{endpoint[1:]}-{width}.png'),full_page=False)
            # Native <details> controls and motion switch work without scripts.
            details=page.locator('details.language')
            details.locator('summary').click()
            assert details.get_attribute('open') is not None
            details.locator('summary').click()
            page.locator('label[for="motion-toggle"]').click()
            assert page.locator('#motion-toggle').is_checked()
            report['native_controls']='language details + animation checkbox passed'
            context.close();browser.close()
    report['status']='passed'
    (ROOT/'docs/browser-layout-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'status':report['status'],'layout_checks':len(report['layout_checks']),
                      'photo_binaries_present':report['photo_binaries_present'],'http_transport_tested':False}))
    return 0

if __name__=='__main__':raise SystemExit(main())

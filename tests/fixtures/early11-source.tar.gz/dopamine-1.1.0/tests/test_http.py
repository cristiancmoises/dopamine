"""Real loopback HTTP integration; independent of Playwright network policy."""
from contextlib import closing
from http.cookies import SimpleCookie
import http.client
from pathlib import Path
from socketserver import ThreadingMixIn
from tempfile import TemporaryDirectory
import threading
import unittest
from urllib.parse import urlencode
from wsgiref.simple_server import WSGIServer,WSGIRequestHandler,make_server
from wsgiref.validate import validator
from app import db
from app.config import Config
from app.web import App
from tests.helpers import Result

class ThreadedServer(ThreadingMixIn,WSGIServer):daemon_threads=True
class QuietHandler(WSGIRequestHandler):
    def log_message(self,*args):pass

class HttpIntegrationTests(unittest.TestCase):
    def test_real_http_signup_purchase_and_casino_with_wsgi_validation(self):
        with TemporaryDirectory() as name:
            path=Path(name)/'db.sqlite3';db.initialize(path)
            server=make_server('127.0.0.1',0,lambda e,s:[],server_class=ThreadedServer,handler_class=QuietHandler)
            port=server.server_port;origin=f'http://127.0.0.1:{port}'
            config=Config(secret='HTTP-integration-test-key-'*4,database=path,site_url=origin,
                allowed_hosts=(f'127.0.0.1:{port}',),secure=False,require_local_photos=False,testing=True)
            server.set_app(validator(App(config)))
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            cookies={}
            def request(endpoint,data=None):
                conn=http.client.HTTPConnection('127.0.0.1',port,timeout=5)
                headers={}
                if cookies:headers['Cookie']='; '.join(k+'='+v for k,v in cookies.items())
                if data is not None:
                    headers.update({'Content-Type':'application/x-www-form-urlencoded','Origin':origin})
                    conn.request('POST',endpoint,urlencode(data).encode(),headers)
                else:conn.request('GET',endpoint,headers=headers)
                response=conn.getresponse();result=Result(response.status,response.getheaders(),response.read());conn.close()
                for key,value in result.headers:
                    if key.lower()=='set-cookie':
                        parsed=SimpleCookie();parsed.load(value)
                        for n,m in parsed.items():cookies[n]=m.value
                return result
            try:
                form=request('/signup').form('/signup')
                result=request('/signup',dict(form,nickname='http_qa',password='HttpCyan!Nebula-2026',adult='yes'))
                self.assertEqual(result.status,200)
                form=request('/product/cars-1-1').form('/buy/cars-1-1')
                result=request('/buy/cars-1-1',dict(form,quantity='2'))
                self.assertEqual(result.status,303)
                self.assertEqual(request(result.location).status,200)
                form=request('/casino/cards').form('/casino/cards')
                result=request('/casino/cards',dict(form,stake='500',card='3'))
                self.assertEqual(result.status,303)
                self.assertEqual(request(result.location).status,200)
                with closing(db.connect(path)) as connection:
                    self.assertEqual(connection.execute('SELECT COUNT(*) FROM purchases').fetchone()[0],1)
                    self.assertEqual(connection.execute('SELECT SUM(bonus) FROM rounds').fetchone()[0],100)
                css=request('/static/style.css')
                self.assertEqual(css.status,200)
                self.assertEqual(css.header('Content-Type'),'text/css; charset=utf-8')
            finally:
                server.shutdown();server.server_close();thread.join(timeout=5)

    def test_secure_proxy_http_registration_all_languages(self):
        """Real HTTP sockets with trusted-proxy HTTPS metadata; TLS termination is not emulated."""
        with TemporaryDirectory() as name:
            path=Path(name)/'db.sqlite3';db.initialize(path)
            origin='https://dopamine.securityops.co'
            config=Config(secret='HTTPS-proxy-integration-key-'*4,database=path,site_url=origin,
                allowed_hosts=('dopamine.securityops.co',),proxy_cidrs=('127.0.0.1/32',),
                secure=True,require_local_photos=False,testing=True)
            server=make_server('127.0.0.1',0,validator(App(config)),server_class=ThreadedServer,handler_class=QuietHandler)
            port=server.server_port;thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                for index,language in enumerate(('pt-br','en','zh','ja')):
                    cookies={}
                    def request(endpoint,data=None,origin_header=origin):
                        conn=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
                        headers={'Host':'dopamine.securityops.co','X-Forwarded-Proto':'https',
                                 'X-Real-IP':f'203.0.113.{120+index}'}
                        if cookies:headers['Cookie']='; '.join(k+'='+v for k,v in cookies.items())
                        if data is not None:
                            headers.update({'Content-Type':'application/x-www-form-urlencoded','Origin':origin_header,'Sec-Fetch-Site':'same-origin'})
                            conn.request('POST',endpoint,urlencode(data).encode(),headers)
                        else:conn.request('GET',endpoint,headers=headers)
                        response=conn.getresponse();result=Result(response.status,response.getheaders(),response.read());conn.close()
                        for key,value in result.headers:
                            if key.lower()=='set-cookie':
                                parsed=SimpleCookie();parsed.load(value)
                                for n,m in parsed.items():cookies[n]=m.value
                        return result
                    page=request('/signup?lang='+language)
                    self.assertEqual(page.header('Referrer-Policy'),'same-origin')
                    self.assertIn('__Host-dopamine',cookies)
                    fields=dict(page.form('/signup'),nickname='secure_http_'+language,password='Cyan-HTTPS-Test!2026',adult='yes')
                    # Old-policy null Origin remains rejected, despite a valid CSRF token.
                    self.assertEqual(request('/signup',fields,origin_header='null').status,403)
                    created=request('/signup',fields)
                    self.assertEqual(created.status,200,created.text)
                    self.assertIn('id="recovery-code"',created.text)
                    self.assertEqual(request('/profile').status,200)
                with closing(db.connect(path)) as connection:
                    self.assertEqual(connection.execute('SELECT COUNT(*) FROM users').fetchone()[0],4)
                    self.assertEqual({row[0] for row in connection.execute('SELECT language FROM users')},{'pt-br','en','zh','ja'})
            finally:server.shutdown();server.server_close();thread.join(timeout=5)

# Changelog

## 1.1.0 — 2026-09-06

512 listings; 384 additions while preserving the original 128. Nine scripted casino games with persistent cosmetic results. Black default background. Language-based simulation currency labels and localized About explanation. Same-origin form referrer policy, atomic registration/session creation, safe inline auth errors and persistent locale cookie. Transactional SQLite v2 migration. Working npm-bridge default and fixed Gunicorn forwarder_headers string. Candidate-first update package with source/.env/image/database snapshots, migration-copy tests, POST maintenance gate, NPM upstream and strict local HTTPS probes, automatic pre-open rollback and explicit later snapshot restoration.

The original MIT license, four-language scope, local-photo model and fictional-only nature are retained. No real payment feature, browser JavaScript, network rewiring or NPM mutation was added.

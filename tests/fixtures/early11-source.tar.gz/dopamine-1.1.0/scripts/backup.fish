#!/usr/bin/env fish
if not command -sq python3
    echo 'ERROR: python3 is required.' >&2
    exit 1
end
set -l directory (dirname (status filename))
python3 "$directory/backup.py" $argv
exit $status
